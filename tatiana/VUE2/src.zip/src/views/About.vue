<template>
  <Header />
  <section>
    <h2>Sobre Nós</h2>
    <p>Somos uma agência dedicada a criar experiências inesquecíveis em suas viagens.</p>
  </section>
  <Footer />
</template>

<script>
import Header from '../components/Header.vue'
import Footer from '../components/Footer.vue'

export default {
  components: { Header, Footer }
}
</script>

