<template>
  <footer>
    <p>© 2025 Agência de Viagem. Todos os direitos reservados.</p>
  </footer>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style scoped>
footer {
  background-color: #24af24ab;
  padding: 1rem;
  text-align: center;
  margin-top: 2rem;
}
</style>
