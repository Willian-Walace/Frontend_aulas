<template>
  <!-- Aqui é onde o conteúdo das páginas aparece -->
  <!-- Quando você navega pelo site, o Vue troca o conteúdo que está aqui -->
  <router-view />
</template>

<script>
export default {
  // Nome do componente principal do site
  name: 'App'
}
</script>
